Date
Created by:
Neil dela Merced
solvalou4ever@yahoo.com
http://solvalou.carbonmade.com/

-------

Low poly Chair

.obj format
330 triangles
165 verts
256x256 diffuse texture


-------
I'm available for contract/commision. Just drop me an email :)

Feel free to use this in your projects, whether it be open source or commercial, as long as proper credit is given(name, email/website).

CC-BY 3.0 License
http://creativecommons.org/licenses/by/3.0/