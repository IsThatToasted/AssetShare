NOT FOR COMMERCIAL USE

*   *   *   *   *

Lamp 01
eb_lamp_01

Lamp 01 made to be used within Unreal. Materials PBR compliant. Great for use in a game or architectural render. For more details or questions feel free to contact me. 

DETAILS:
- Tri Count: 610
- Color Map: eb_lamp_01_c
- Roughness Map: Packed in RED channel of eb_lamp_01_g
- Metal Map: Packed in GREEN channel of eb_lamp_01_g
- Emissive Mask: Packed in BLUE channel of eb_lamp_01_g
- Normal Map: eb_lamp_01_n

*   *   *   *   *

For questions contact Ernesto at ernestbezera@gmail.com